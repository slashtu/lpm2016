<?php

echo do_shortcode( '[mk_blog style="modern"]' );